#ifndef __DELAY_H__
#define __DELAY_H__
#include <STC15F2K60S2.H>
#include <intrins.h>
void Delay_ms(unsigned int ms);//@11.0592MHz
void delay_10us(unsigned int us);		//@11.0592MHz
void delay_1us(unsigned int us);		//@11.0592MHz



#endif

#ifndef __DELAY_H__
#define __DELAY_H__
#include <STC15F2K60S2.H>
#include <intrins.h>
void Delay_ms(unsigned char ms);//@11.0592MHz



#endif

/* 头文件声明区 */
#include <STC15F2K60S2.H>//单片机寄存器专用头文件
#include <Init.h>//初始化底层驱动专用头文件
#include <Led.h>//Led底层驱动专用头文件
#include <Key.h>//按键底层驱动专用头文件
#include <Seg.h>//数码管底层驱动专用头文件
#include <ultrasound.h>//超声波底层驱动专用头文件
#include "iic.h"//ADDA底层驱动专用头文件

/* 变量声明区 */
unsigned char Key_Val,Key_Down,Key_Old,Key_Up;//按键专用变量
unsigned char Key_Slow_Down;//按键减速专用变量
unsigned char Seg_Buf[8] = {10,10,10,10,10,10,10,10};//数码管显示数据存放数组
unsigned char Seg_Point[8] = {0,0,0,0,0,0,0,0};//数码管小数点数据存放数组
unsigned char Seg_Pos;//数码管扫描专用变量
unsigned int Seg_Slow_Down;//数码管减速专用变量
unsigned char ucLed[8] = {0,0,0,0,0,0,0,0};//Led显示数据存放数组
unsigned char Seg_Disp_Mode;//数码管显示模式变量 0-电压 1-参数 2-测距
unsigned char Voltage_Parameter_Disp[2] = {45,5};//电压参数数据显示数组 默认上限4.5V 下限0.5V
unsigned char Voltage_Parameter_Ctrol[2] = {45,5};//电压参数数据控制数组 默认上限4.5V 下限0.5V
unsigned char Wave_Dat;//实时距离变量
unsigned char Timer_100Ms;//100毫秒计时变量
unsigned char Da_Output;//电压输出变量
float Voltage;//实时电压值变量
bit Wave_Flag;//超声波测距使能标志位 0-不使能 1-使能
bit Voltage_Parameter_Index;//电压参数数组指针 0-上限 1-下限
bit Led_Star_Flag;//Led闪烁标志位

/* 键盘处理函数 */
void Key_Proc()
{
	if(Key_Slow_Down) return;
	Key_Slow_Down = 1;//键盘减速程序

	Key_Val = Key_Read();//实时读取键码值
	Key_Down = Key_Val & (Key_Old ^ Key_Val);//捕捉按键下降沿
	Key_Up = ~Key_Val & (Key_Old ^ Key_Val);//捕捉按键上降沿
	Key_Old = Key_Val;//辅助扫描变量

	switch(Key_Down)
	{
		case 4://界面切换按键
			if(++Seg_Disp_Mode == 3) //数码管显示模式在0-2之间循环切换
				Seg_Disp_Mode = 0;
			if(Seg_Disp_Mode == 2) //从参数设置界面退出
			{
				if(Voltage_Parameter_Disp[0] > Voltage_Parameter_Disp[1]) //参数设置合理
				{
					Voltage_Parameter_Ctrol[0] = Voltage_Parameter_Disp[0];//保存设置参数
					Voltage_Parameter_Ctrol[1] = Voltage_Parameter_Disp[1];
				} 
				else //参数设置不合理
				{
					Voltage_Parameter_Disp[0] = Voltage_Parameter_Ctrol[0];//复位设置参数
					Voltage_Parameter_Disp[1] = Voltage_Parameter_Ctrol[1];
				}
			}
		break;
		case 5://参数选择按键
			if(Seg_Disp_Mode == 1) //处于参数设置界面
				Voltage_Parameter_Index ^= 1;
		break;
		case 6://参数自加按键
			if(Seg_Disp_Mode == 1) //处于参数设置界面
			{
				Voltage_Parameter_Disp[Voltage_Parameter_Index] += 5;
				if(Voltage_Parameter_Disp[Voltage_Parameter_Index] > 50) //限制上限为5V
					Voltage_Parameter_Disp[Voltage_Parameter_Index] = 5;
			}
		break;
		case 7://参数自减按键
			if(Seg_Disp_Mode == 1) //处于参数设置界面
			{
				Voltage_Parameter_Disp[Voltage_Parameter_Index] -= 5;
				if(Voltage_Parameter_Disp[Voltage_Parameter_Index] < 5) //限制下限为0.5V
					Voltage_Parameter_Disp[Voltage_Parameter_Index] = 50;
			}
		break;
	}
}

/* 信息处理函数 */
void Seg_Proc()
{
	if(Seg_Slow_Down) return;
	Seg_Slow_Down = 1;//数码管减速程序

	/* 数据读取区域 */
	Voltage = Ad_Read(0x03) / 51.0;//实时获取电压数据
	if(Wave_Flag == 1) //超声波测距使能
	{
		Wave_Dat = Ut_Wave_Data();//实时获取距离数据
		if(Wave_Dat <= 20) //获取输出电压值
			Da_Output = 1;
		else if(Wave_Dat >= 80)
			Da_Output = 5;
		else
			Da_Output = (4 / 60) * (Wave_Dat - 20);
	}
	else
		Da_Output = 0;//超声波测距未使能时 输出0V电压
	
	/* 信息显示区域 */
	switch(Seg_Disp_Mode)
	{
		case 0:
			Seg_Point[5] = 1;//第六位数码管小数点使能
			Seg_Buf[0] = 11;//标识符U
			Seg_Buf[5] = (unsigned char)Voltage;
			Seg_Buf[6] = (unsigned int)(Voltage * 100) / 10 % 10;
			Seg_Buf[7] = (unsigned int)(Voltage * 100) % 10;
		break;
		case 1:
			Seg_Point[5] = 0;//第六位数码管小数点熄灭
			Seg_Point[3] = Seg_Point[6] = 1;//第四位数码管和第七位数码管小数点使能
			Seg_Buf[0] = 12;//标识符P
			Seg_Buf[3] = Voltage_Parameter_Disp[0] / 10 % 10;
			Seg_Buf[4] = Voltage_Parameter_Disp[0] % 10;
			Seg_Buf[5] = 10;
			Seg_Buf[6] = Voltage_Parameter_Disp[1] / 10 % 10;
			Seg_Buf[7] = Voltage_Parameter_Disp[1] % 10;
		break;
		case 2:
			Seg_Buf[0] = 13;//标识符L
			Seg_Point[3] = Seg_Point[6] = 0;//第四位数码管和第七位数码管小数点熄灭
			Seg_Buf[3] = Seg_Buf[4] = 10;
			Seg_Buf[5] = Wave_Flag?Wave_Dat / 100 % 10:14;
			Seg_Buf[6] = Wave_Flag?Wave_Dat / 10 % 10:14;
			Seg_Buf[7] = Wave_Flag?Wave_Dat % 10:14;
		break;
	}
}

/* 其他显示函数 */
void Led_Proc()
{
	unsigned char i;//For循环专用变量
	Wave_Flag = ((Voltage > (Voltage_Parameter_Ctrol[1] / 10.0)) && (Voltage < (Voltage_Parameter_Ctrol[0] / 10.0))); //测距使能条件
	Da_Write(Da_Output * 51);//实时输出电压值
	for(i=0;i<3;i++) //互斥点亮
		ucLed[i] = (i == Seg_Disp_Mode);
	ucLed[7] = Led_Star_Flag?Wave_Flag:0;
}

/* 定时器0中断初始化函数 */
void Timer0Init(void)		//1毫秒@12.000MHz
{
	AUXR &= 0x7F;		//定时器时钟12T模式
	TMOD &= 0xF0;		//设置定时器模式
	TL0 = 0x18;		//设置定时初始值
	TH0 = 0xFC;		//设置定时初始值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
	ET0 = 1;    //定时器中断0打开
	EA = 1;     //总中断打开
}

/* 定时器0中断服务函数 */
void Timer0Server() interrupt 1
{  
	if(++Key_Slow_Down == 10) Key_Slow_Down = 0;//键盘减速专用
	if(++Seg_Slow_Down == 500) Seg_Slow_Down = 0;//数码管减速专用
	if(++Seg_Pos == 8) Seg_Pos = 0;//数码管显示专用
	Seg_Disp(Seg_Pos,Seg_Buf[Seg_Pos],Seg_Point[Seg_Pos]);
	Led_Disp(Seg_Pos,ucLed[Seg_Pos]);
	if(++Timer_100Ms == 100)
	{
		Timer_100Ms = 0;
		Led_Star_Flag ^= 1;
	}
}

/* Main */
void main()
{
	System_Init();
	Timer0Init();
	while (1)
	{
		Key_Proc();
		Seg_Proc();
		Led_Proc();
	}
}
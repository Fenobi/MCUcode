#include <STC15F2K60S2.H>

void System_Init();
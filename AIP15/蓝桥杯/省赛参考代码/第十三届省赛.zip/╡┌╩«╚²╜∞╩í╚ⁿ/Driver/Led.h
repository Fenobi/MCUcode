#include <STC15F2K60S2.H>

void Led_Disp(unsigned char addr,enable);
void Beep(unsigned char flag);
void Relay(unsigned char flag);